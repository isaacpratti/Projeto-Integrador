const btComecar = document.getElementById("btComecar");
const btBasico = document.getElementById("btBasico");
const btIntermediario = document.getElementById("btIntermediario");
const btAvancado = document.getElementById("btAvancado");

